//Verilog HDL for "BVU025_Lary", "Buffer_DIG" "functional"


module Buffer_DIG (
    input  wire in,
    output wire out
);
    assign out = in;
endmodule

