//Verilog HDL for "BVU025_Lary", "DIG_INV" "functional"


module DIG_INV (input x, output y);
	assign y = ~x;
endmodule
