`timescale 1ns / 1ps
/*
** =========================================================================
** SystemVerilog Virtual Host & I2C Master Controller (py_tester)
** Library: BVU025_Lary
** Features:
**   1. Real-time Python Dynamic Co-Simulation Interface (IPC / DPI-C ready)
**   2. Complete I2C Master Driver Engine (Start, Stop, WriteReg, ReadReg, ACK)
**   3. 6-bit Successive Approximation Register (SAR) Trim Engine
**   4. Digital Mode Controls: TMIRefOn, TMIRefMeas, NvTrmIref[5:0], dIRefTMO
** =========================================================================
*/

module py_tester (
    // DUT Digital Trim & Test Mode Controls
    output logic        TMIRefOn,
    output logic        TMIRefMeas,
    output logic [5:0]  NvTrmIref,
    input  logic        dIRefTMO,

    // I2C Master Interface (Open-Drain / Tri-state capable)
    inout  wire         SCL,
    inout  wire         SDA
);

    // Internal I2C Open-Drain Drive registers
    logic scl_drive_low = 1'b0;
    logic sda_drive_low = 1'b0;

    assign SCL = scl_drive_low ? 1'b0 : 1'bz;
    assign SDA = sda_drive_low ? 1'b0 : 1'bz;

    // Timing parameters for I2C (Fast Mode: 400kHz, T_high=1.25us, T_low=1.25us)
    parameter real T_I2C_HALF = 1250.0; // 1.25us in ns

    // Variables for IPC handshake with Python
    integer fp_cmd, fp_resp, num_read;
    integer iint_code = 0;
    real abstime_us;

    // =====================================================================
    // 1. I2C Master Low-Level Protocol Tasks
    // =====================================================================
    
    task i2c_start();
        begin
            sda_drive_low <= 1'b0; // SDA High
            scl_drive_low <= 1'b0; // SCL High
            #(T_I2C_HALF);
            sda_drive_low <= 1'b1; // SDA Low while SCL High (START)
            #(T_I2C_HALF);
            scl_drive_low <= 1'b1; // SCL Low
            #(T_I2C_HALF);
        end
    endtask

    task i2c_stop();
        begin
            sda_drive_low <= 1'b1; // SDA Low
            scl_drive_low <= 1'b1; // SCL Low
            #(T_I2C_HALF);
            scl_drive_low <= 1'b0; // SCL High
            #(T_I2C_HALF);
            sda_drive_low <= 1'b0; // SDA High while SCL High (STOP)
            #(T_I2C_HALF);
        end
    endtask

    task i2c_write_byte(input [7:0] byte_data, output logic ack);
        integer b;
        begin
            for (b = 7; b >= 0; b = b - 1) begin
                sda_drive_low <= ~byte_data[b];
                #(T_I2C_HALF);
                scl_drive_low <= 1'b0; // SCL High (Sample)
                #(T_I2C_HALF);
                scl_drive_low <= 1'b1; // SCL Low
                #(T_I2C_HALF);
            end

            // Release SDA for ACK from Slave
            sda_drive_low <= 1'b0;
            #(T_I2C_HALF);
            scl_drive_low <= 1'b0; // SCL High
            #(T_I2C_HALF / 2);
            ack = (SDA === 1'b0);  // Sample ACK (Low means ACK)
            #(T_I2C_HALF / 2);
            scl_drive_low <= 1'b1; // SCL Low
            #(T_I2C_HALF);
        end
    endtask

    task i2c_read_byte(output logic [7:0] byte_data, input logic send_ack);
        integer b;
        begin
            sda_drive_low <= 1'b0; // Release SDA
            for (b = 7; b >= 0; b = b - 1) begin
                scl_drive_low <= 1'b0; // SCL High (Sample)
                #(T_I2C_HALF);
                byte_data[b] = (SDA === 1'b1);
                scl_drive_low <= 1'b1; // SCL Low
                #(T_I2C_HALF);
            end

            // Master sends ACK or NACK
            sda_drive_low <= send_ack ? 1'b1 : 1'b0;
            #(T_I2C_HALF);
            scl_drive_low <= 1'b0;
            #(T_I2C_HALF);
            scl_drive_low <= 1'b1;
            #(T_I2C_HALF);
            sda_drive_low <= 1'b0;
        end
    endtask

    task i2c_write_reg(input [6:0] slave_addr, input [7:0] reg_addr, input [7:0] data);
        logic ack1, ack2, ack3;
        begin
            $display("[SV-I2C @ %0t ns] WRITE Slave 0x%02h, Reg 0x%02h = 0x%02h", $time, slave_addr, reg_addr, data);
            i2c_start();
            i2c_write_byte({slave_addr, 1'b0}, ack1); // Write operation
            i2c_write_byte(reg_addr, ack2);
            i2c_write_byte(data, ack3);
            i2c_stop();
        end
    endtask

    task i2c_read_reg(input [6:0] slave_addr, input [7:0] reg_addr, output logic [7:0] data);
        logic ack1, ack2, ack3;
        begin
            i2c_start();
            i2c_write_byte({slave_addr, 1'b0}, ack1);
            i2c_write_byte(reg_addr, ack2);
            i2c_start(); // Repeated START
            i2c_write_byte({slave_addr, 1'b1}, ack3); // Read operation
            i2c_read_byte(data, 1'b0); // NACK on last byte
            i2c_stop();
            $display("[SV-I2C @ %0t ns] READ Slave 0x%02h, Reg 0x%02h -> 0x%02h", $time, slave_addr, reg_addr, data);
        end
    endtask

    // =====================================================================
    // 2. Real-Time Dynamic Timeline & SAR Calibration Sequence
    // =====================================================================

    initial begin
        TMIRefOn   = 1'b0;
        TMIRefMeas = 1'b0;
        NvTrmIref  = 6'd0;

        // 1. Initial Step: Reset Python Controller
        fp_cmd = $fopen("/tmp/py_tester_cmd.txt", "w");
        if (fp_cmd) begin
            $fwrite(fp_cmd, "INIT 0.0\n");
            $fclose(fp_cmd);
        end

        // 2. Power-up delay (100us)
        #100000;
        $display("[SV Tester @ %0t ns] -> Power-Up State Complete.", $time);

        // 3. Enable Trim Mode (t = 390us)
        #290000;
        TMIRefOn = 1'b1;
        $display("[SV Tester @ %0t ns] -> TMIRefOn = 1'b1 (Trim Mode Enabled)", $time);

        // 4. SAR Successive Approximation Loops (500us ~ 1300us)
        #110000; // t = 500us
        
        repeat (6) begin
            // Send Current Time and sampled dIRefTMO to Python
            abstime_us = $time / 1000.0;
            fp_cmd = $fopen("/tmp/py_tester_cmd.txt", "w");
            if (fp_cmd) begin
                $fwrite(fp_cmd, "TIME %g CMP %g\n", abstime_us / 1000.0, (dIRefTMO === 1'b1 ? 3.3 : 0.0));
                $fclose(fp_cmd);
            end

            // Read new Trim Code from Python
            #1000;
            fp_resp = $fopen("/tmp/py_tester_resp.txt", "r");
            if (fp_resp) begin
                num_read = $fscanf(fp_resp, "%*f %*f %*f %*d %*f %d", iint_code);
                $fclose(fp_resp);
                NvTrmIref = iint_code[5:0];
                $display("[SV Tester @ %0t ns] -> Dynamic Python SAR Code: %0d (%b)", $time, NvTrmIref, NvTrmIref);
            end

            #149000; // Next step delay (~150us)
        end

        // 5. Switch to Measurement Mode (t = 1.41ms)
        TMIRefOn   = 1'b0;
        TMIRefMeas = 1'b1;
        $display("[SV Tester @ %0t ns] -> Switch to Measure Mode: TMIRefOn=0, TMIRefMeas=1", $time);

        // 6. Test I2C communication demo at 1.5ms
        #90000; // t = 1.5ms
        i2c_write_reg(7'h48, 8'h10, {2'b00, NvTrmIref});
    end

endmodule
